# Hostinger deployment checklist (planning only)

**Do not upload this public GitHub starter as a replacement for `public_html`.** It is not a standalone PHP website.

Before integration, create a backup of the existing Core PHP project and MySQL database. Do not change production before reviewing the full source and testing on a staging copy.

- Verify existing login and sessions for **multiple** users, not just the owner's admin account.
- Audit current Drive and YouTube OAuth connections and Instagram/Meta permissions.
- Confirm database engine/version and unique indexes for scheduled jobs.
- Review cron frequency and PHP execution limits on your Hostinger plan.
- Configure secret storage outside web root or with access blocked.
- Validate upload file types, quotas, retention, media URL security, CSRF, SQL prepared statements, and permission checks.
- Separate per-destination credentials, queue rows and errors by user.
- Add schedule tests for timezones, DST, duplicates, rate limits and retries.
- Implement monitoring and an emergency pause for auto-publishing.

Deploy private backend changes only after explicit approval and tests.
