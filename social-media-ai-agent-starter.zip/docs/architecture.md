# Architecture — Public Skill Pack / Private PHP Service

## Public (this repo)

- Agent Skill instructions (`skills/*/SKILL.md`)
- Windows launcher with a fixed HTTPS dashboard URL
- No production credentials, account data, backend business rules or browser session access

## Private (existing Hostinger Core PHP + MySQL site)

- Account registration/login and session management
- Per-user Google Drive / YouTube / Meta OAuth connections
- Encrypted token storage with rotation and revocation
- Per-destination selection and account ownership checks
- Queue and cron: discover > ingest > validate > analyze > draft > schedule > upload > verify > audit
- Error handling: backoff, quota awareness, idempotency keys and dead-letter handling
- PostgreSQL is **not** required; MySQL with secure transactions and indexes is sufficient for an initial deployment

## Request flow

```text
Installed AI Skill -- generates metadata proposal --> User / approved private interface
Public launcher -- opens https URL --------> Hostinger PHP Dashboard
Authenticated PHP Backend -- user-scoped OAuth --> Official platform API
Private Cron --> controlled jobs --> publishing results / per-destination status
```

## Data model (proposal, not yet an applied migration)

- `users(id, ... )`
- `social_connections(id, user_id, provider, provider_account_id, scopes, encrypted_tokens, expiry, status)`
- `source_folders(id, user_id, connection_id, provider_folder_id, active)`
- `content_assets(id, user_id, source_file_id, revision, checksum, media_type, status)`
- `destinations(id, user_id, connection_id, provider, provider_destination_id, active)`
- `publish_jobs(id, user_id, content_asset_id, destination_id, scheduled_at_utc, status, idempotency_key, attempts)`
- `publish_attempts(id, job_id, provider_request_id, http_status, error_code, created_at)`
- `audit_events(id, actor_user_id, target_type, target_id, action, created_at)`

All ownership must be checked server-side. Use unique indexes on deduplication/idempotency keys and row locking for workers to avoid duplicate posts. Keep media uploads outside publicly writable directories.

## Integration phases

1. Public CLI + instruction-only skills (this starter).
2. Audit the **existing** PHP code and database before changing anything.
3. Authenticated API endpoints with authorization, CSRF / session protections and rate limits.
4. Secure OAuth refresh, per-user Drive ingest, queues and destination scheduling.
5. Official YouTube and Meta publishing integrations, with platform-specific checks and audit trail.
6. Only after testing: public multi-user dashboard use; expand optional agent-to-site authenticated controls.

**Do not assume phase 3-6 already exists.**
