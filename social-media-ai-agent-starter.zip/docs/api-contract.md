# Proposed API Contract — NOT implemented

This document specifies a **future** authenticated Core PHP integration. No endpoint in this document is claimed to exist today. Choose a dedicated versioned prefix, e.g. `/api/agent/v1`, only after auditing existing routes and permissions.

## Authentication

- Browser dashboard: secure, HttpOnly, SameSite cookie sessions plus CSRF protection for mutations.
- External AI Agent: optional user-generated limited-scope personal access token, delivered over HTTPS and stored in OS secret storage rather than the public GitHub repo; alternatively OAuth 2.0 Authorization Code + PKCE for an approved client.
- All endpoints: user/tenant authorization, rate limits, request IDs and audit logs.
- Do not reuse admin session cookies in a CLI and do not put long-lived access tokens in URL query strings.

## Potential routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/agent/v1/me` | Authenticated user and API scopes |
| GET | `/api/agent/v1/destinations` | Current user's connected, permitted destinations |
| GET | `/api/agent/v1/assets` | Current user's eligible content |
| POST | `/api/agent/v1/drafts` | Validate/store metadata draft |
| POST | `/api/agent/v1/schedules` | Create a permission-checked posting job; require idempotency key |
| GET | `/api/agent/v1/jobs/{job_id}` | Current user's job status |
| POST | `/api/agent/v1/jobs/{job_id}/cancel` | Cancel a queued, not-yet-executed job |

### Example proposal (not an active API call)

```json
{
  "asset_id": "asset_example",
  "destination_id": "destination_example",
  "scheduled_at_utc": "2026-11-02T12:00:00Z",
  "title": "Example verified title",
  "caption": "Example caption",
  "idempotency_key": "example-unique-request-id"
}
```

## Queue processing state machine

`draft → validated → queued → uploading → published` or `failed` / `cancelled`. Retries must be bounded and idempotent; ambiguous provider responses must be reconciled with provider-side state before repeating an upload.

## Publishing authorization

Use the official Google/YouTube OAuth and Meta Graph API requirements for the specific account type and approved permission scope. Eligibility and review requirements can change; check current provider docs before implementing. Keep refresh tokens server-side, encrypted. No OAuth secrets should be embedded in PowerShell, agent skills, JavaScript, or public GitHub files.
