@echo off
setlocal
echo Installing the locally reviewed Social Media AI Agent launcher...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1"
if errorlevel 1 (
  echo Installation failed.
  pause
  exit /b 1
)
echo.
echo Close and reopen PowerShell, then type: automation start
pause
