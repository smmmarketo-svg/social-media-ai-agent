# Security

This public repository intentionally contains **no credentials** and **no live API connections**.

Never commit API keys, OAuth client secrets, access tokens, refresh tokens, session cookies, production `.env` files, database exports, webhook secrets, personal data, or Hostinger login details. Keep all tokens server-side and encrypted at rest where possible; restrict access per user and destination.

Before making the PHP website accessible to other users, implement server-side authentication and authorization, CSRF protection, HTTPS, session security, tenant/user data separation, scoped OAuth connections, consent, audit logs, rate limits, and safe background publishing with idempotency.

Report vulnerabilities privately to the repository owner. Do not create a public issue containing an exploit or credential.
