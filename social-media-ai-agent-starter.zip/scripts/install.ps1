param([switch]$InstallSkills)
$ErrorActionPreference = 'Stop'

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$launcher = Join-Path $repoRoot 'launcher\automation.cmd'
if (-not (Test-Path -LiteralPath $launcher -PathType Leaf)) {
    throw 'Launcher file not found; run from an extracted copy of the repository.'
}

$binDir = Join-Path $env:LOCALAPPDATA 'Programs\SocialMediaAIAgent\bin'
New-Item -ItemType Directory -Path $binDir -Force | Out-Null
Copy-Item -LiteralPath $launcher -Destination (Join-Path $binDir 'automation.cmd') -Force

$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$segments = @($userPath -split ';' | Where-Object { $_ -and $_.Trim() })
$alreadyPresent = @($segments | Where-Object { $_.TrimEnd('\') -ieq $binDir.TrimEnd('\') }).Count -gt 0
if (-not $alreadyPresent) {
    $newPath = (@($segments) + $binDir) -join ';'
    [Environment]::SetEnvironmentVariable('Path', $newPath, 'User')
    Write-Host 'Added launcher to your user PATH. Reopen PowerShell after installation.'
} else {
    Write-Host 'Launcher is already on your user PATH.'
}

if ($InstallSkills) {
    $skillsRoot = Join-Path $repoRoot 'skills'
    $destinations = @(
        (Join-Path $HOME '.claude\skills'),
        (Join-Path $HOME '.codex\skills')
    )
    foreach ($destination in $destinations) {
        New-Item -ItemType Directory -Path $destination -Force | Out-Null
        Get-ChildItem -LiteralPath $skillsRoot -Directory | ForEach-Object {
            $target = Join-Path $destination $_.Name
            if (Test-Path -LiteralPath $target) {
                Write-Host "Skipping already installed skill: $target (no overwrite)"
            } else {
                Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse
                Write-Host "Installed skill to $target"
            }
        }
    }
}

Write-Host 'Installed. Open a NEW PowerShell window and run: automation start'
Write-Host 'Note: This launcher does not install PHP or grant dashboard access.'
