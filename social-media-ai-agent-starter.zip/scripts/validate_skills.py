#!/usr/bin/env python3
"""Tiny dependency-free structural check, not a complete Agent Skills spec validator."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1] / "skills"
errors = []
for folder in sorted(ROOT.iterdir()):
    if not folder.is_dir():
        continue
    file = folder / "SKILL.md"
    if not file.exists():
        errors.append(f"{folder.name}: missing SKILL.md")
        continue
    content = file.read_text(encoding="utf-8")
    parts = content.split("---", 2)
    if len(parts) < 3 or parts[0].strip() or not parts[2].strip():
        errors.append(f"{folder.name}: YAML frontmatter or body missing")
        continue
    fields = dict(re.findall(r"^([a-z-]+):\s*(.*)$", parts[1], re.M))
    name = fields.get("name", "")
    description = fields.get("description", "")
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name) or name != folder.name:
        errors.append(f"{folder.name}: invalid or mismatched name")
    if not 1 <= len(description) <= 1024:
        errors.append(f"{folder.name}: missing or oversized description")

if errors:
    print("FAILED:\n" + "\n".join(errors))
    sys.exit(1)
print(f"PASS: {len([d for d in ROOT.iterdir() if d.is_dir()])} skills have valid basic structure")
