# Agent guidance

This project contains **public, instruction-based** social media agent skills. Choose the smallest matching skill for the user's task.

- Never claim a video was uploaded, a post scheduled, or a Google Drive file imported unless the authorized private backend confirms the action.
- Draft, analyze and prepare freely using user-provided materials. Use connected tools only when they are available and authorized.
- Confirm a destination and account identity before creating real posts. Respect user-configured automatic-publishing permissions if supported by the private backend.
- Avoid duplicate posts, leaked credentials, copyrighted material without rights, and misleading claims.
- Follow each destination's official API terms and publishing limits.
- Do not ask users to paste OAuth client secrets, access tokens or passwords into a public chat or repository.
- A `SKILL.md` does not itself provide API access or additional model capabilities.
