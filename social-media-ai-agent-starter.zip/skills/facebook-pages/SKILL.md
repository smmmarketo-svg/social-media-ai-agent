---
name: facebook-pages
description: Prepare Facebook Page posts and platform-appropriate video captions from supplied content. Use for Page content drafting and publication plans, not direct API posting.
---

# Facebook Pages Content Planner

## Workflow

1. Identify the Page audience, objective, message, video summary and brand voice.
2. Draft a conversational Page post, short intro and clear call to action.
3. Suggest optional short, medium, and informative variants.
4. Propose a schedule only if a time zone and posting frequency are known.
5. Return content with factual accuracy checks and needed permissions.

## Guardrails

Do not claim to publish to personal profiles or obtain Page permissions automatically. Publishing requires authorized Page access via an approved Meta integration. Do not expose tokens or private account details.
