---
name: google-drive-ingest
description: Design safe intake and deduplication of authorized Google Drive media for a Core PHP publishing queue. Use when planning Drive folder ingestion; do not access files without an authorized connector.
---

# Google Drive Ingestion Planner

## Workflow

1. Identify the user-authorized folder and list the kinds of assets permitted (video, image, caption metadata).
2. Propose discovery using official Drive OAuth and scoped access on the private PHP backend.
3. For each file, record provider file ID, parent folder, modification time, size, checksum or content fingerprint where available, and permissions.
4. Use a durable `(provider_account_id, file_id, revision)` deduplication strategy plus a per-destination publishing idempotency key.
5. Enqueue eligible media for analysis; queue platform-specific drafts and schedules separately.
6. Handle deletion, replacement, insufficient permissions, retries, expired OAuth and duplicate notifications.

## Guardrails

This skill describes the workflow only; it does not contain an OAuth client, live Drive account access, scheduled worker, or server tokens. Never suggest public sharing of private source folders to avoid OAuth.
