---
name: instagram-reels
description: Draft Instagram Reels hooks, captions, relevant hashtags and a publish plan based on the user's video. Use for Instagram professional-account content preparation, not direct posting.
---

# Instagram Reels Content Planner

## Input

Use the actual video summary/transcript, audience, tone, locale, campaign, and call to action.

## Workflow

1. Summarize the reel's authentic takeaway in one line.
2. Propose three hook options suited to the video.
3. Draft concise caption variants, a relevant non-spammy hashtag selection, accessibility text where appropriate, and a CTA.
4. Provide a final draft with optional publishing slot suggestions based only on known user preferences.
5. Record missing facts requiring confirmation before any real post.

## Guardrails

Do not invent influencer endorsements, collaborations, location tags, results, or source rights. Direct Instagram publishing requires an eligible professional account and authorized server integration; this skill does not perform it.
