---
name: youtube-seo
description: Create truthful, discoverable YouTube titles, descriptions, chapters and SEO metadata from user-provided video information. Use when preparing video SEO copy; do not upload videos.
---

# YouTube SEO Writer

## Input

Ask for or use the video topic, language, audience, transcript or reliable synopsis, format (standard video/Short), primary goal and brand voice.

## Workflow

1. Identify the video's actual subject and likely search intent from provided content.
2. Draft three distinct, clear title options without unsupported claims or clickbait.
3. Write a readable description with the strongest information in its opening lines; include relevant calls to action and factual references as supplied.
4. Propose a short keyword set and a restrained set of closely related hashtags.
5. If a transcript with timestamps is available, suggest chapters using real timestamps only; otherwise omit times.
6. Output an editable `title`, `description`, `keywords`, `hashtags`, `chapters`, and `confidence_notes` summary.

## Guardrails

Do not claim to have watched media you cannot access. Do not fabricate video chapters, links, sources, sponsors, endorsements, or platform rankings. This is content generation, not an upload tool.
