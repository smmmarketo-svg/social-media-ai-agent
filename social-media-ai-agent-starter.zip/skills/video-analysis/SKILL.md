---
name: video-analysis
description: Derive content summaries and platform-specific creative ideas from actual provided video material or transcripts. Use when users ask to analyze video for SEO or post ideas; disclose inaccessible media.
---

# Video Content Analysis

## Input

Prefer actual accessible video frames, audio transcript, creator notes and relevant metadata. If media is inaccessible, request a transcript or summary without claiming direct inspection.

## Workflow

1. Distinguish directly observed visual events, transcribed spoken words and user-provided descriptions.
2. Summarize subject, language, visible scenes and opening hook.
3. Identify safe, non-sensitive highlights and suggested clip segments only when timings are reliable.
4. Produce an outline useful for YouTube, Instagram Reels and Facebook Pages.
5. Provide uncertainty notes and recommended human verification points.

## Guardrails

Do not transcribe audio that was not provided, invent visual content, infer sensitive attributes, or claim that platform APIs have been called. Respect privacy and media usage rights.
