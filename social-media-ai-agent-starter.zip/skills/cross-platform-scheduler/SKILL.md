---
name: cross-platform-scheduler
description: Plan and check a timezone-aware posting calendar across YouTube, Instagram and Facebook. Use when allocating content slots, preventing duplicates, or respecting posting frequencies; do not claim jobs have been queued.
---

# Cross-Platform Scheduling Planner

## Input

Use destination IDs or friendly names (never secrets), account-specific daily frequency, timezone, permitted publish windows, content readiness, platform capabilities and already-scheduled slots.

## Steps

1. Convert all intended slots into the destination timezone; keep UTC times for storage.
2. Enforce per-account maximum publications per day, minimum spacing and blackout times.
3. Check each asset has the correct format for every destination.
4. Create a `content_id × destination_id` idempotency key to avoid repeats.
5. Build a proposal containing destination, local slot, UTC slot, content ID, status (`proposed`) and validation notes.
6. Flag conflicts, missing OAuth scopes, disconnected accounts and rate/quota uncertainty.

## Safety

This skill only plans. Creating a real schedule requires an authorized backend to accept it and confirm a `job_id` and status. Never represent a proposal as published. Do not invent live channel availability or quota.
