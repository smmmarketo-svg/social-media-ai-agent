# Social Media AI Agent

> Public AI Agent Skills and a Windows PowerShell launcher for a separately hosted, private Core PHP social media automation dashboard.

**Status: v0.1 starter.** The launcher opens the existing website. The public skills provide content planning, SEO, and workflow instructions. **This repository does not yet perform YouTube, Facebook, or Instagram publishing, authenticate to the dashboard, or access Google Drive.** Those actions require server-side integration, valid OAuth authorization, and the user's permissions.

## Features

- Draft platform-specific YouTube titles, descriptions, metadata and content plans.
- Draft Instagram Reels and Facebook Pages captions and schedules.
- Propose cross-platform schedules that respect each destination's frequency and time zone.
- Plan safe Google Drive intake workflows without copying or exposing third-party credentials.
- Open the existing PHP dashboard using the local `automation start` command on Windows.

## Windows Quick Start

1. Download this repository using **Code > Download ZIP** on GitHub. Extract the folder.
2. Review the `install.cmd`, `scripts/install.ps1`, and `launcher/automation.cmd` files before running them.
3. Double-click `install.cmd` to install the launcher **for your Windows user only**, without administrator privileges.
4. **Close and reopen PowerShell**, then run:

   ```powershell
   automation start
   ```

This opens <https://bajarmart.com/index.php> in your default browser. The user still needs the proper website account and authorization. The current hosted dashboard is not bundled into this repo.

Commands: `automation start`, `automation help`, `automation version`.

**Optional skill installation:** To copy these skill folders to your current Windows user's Claude Code and Codex folders, run the installer from the extracted repository in PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -InstallSkills
```

The execution-policy override is **for this one process only**. Review the local script first. It does not change the machine-wide policy. The installer copies each skill folder to `~/.claude/skills` and `~/.codex/skills` (if desired, remove `-InstallSkills` to install only the launcher). Individual ChatGPT environments may use another import or plugin workflow. Skill support is not identical across products.

## Skills

| Skill | Purpose |
| --- | --- |
| `youtube-seo` | Optimized video title, description, chapters, keywords |
| `instagram-reels` | Reels hook, caption, hashtags and CTA |
| `facebook-pages` | Pages captions and publishing plan |
| `cross-platform-scheduler` | Destination-aware content scheduling |
| `video-analysis` | Analyze provided audio/transcript and visual summaries |
| `google-drive-ingest` | Ingestion and deduplication plan |

Each skill is in `skills/<skill-name>/SKILL.md` and follows the open Agent Skills convention.

## Architecture

```text
Windows user -- automation start --> Browser --> Hostinger PHP dashboard
                                             |
                                             v
                                   authenticated user session
                                             |
                                             v
                               Private Core PHP backend + MySQL
                                             |
                +----------------------------+----------------------------+
                v                            v                            v
           Google Drive                YouTube Data API            Meta Graph API
        Authorized OAuth only       OAuth + upload/quota        Authorized Page/IG
```

**Separation:** This public repository must never contain private PHP source code, `.env` files, OAuth secrets or tokens, database dumps, customer lists, or host credentials. See `docs/architecture.md`, `docs/api-contract.md`, and `SECURITY.md`.

## Hosting and account safety

- The public launcher **does not grant** access to an administrator account.
- Multi-user registration, account isolation, API permissions and platform OAuth must be implemented in the private Core PHP website before offering public access.
- The remote website controls feature availability; nothing is bypassed by installing this repository.
- Do not publish customer data, private keys, PHP backend credentials, or production configuration.

## Development

Requires Python 3 for the included static skill checks:

```bash
python3 scripts/validate_skills.py
```

## License

MIT — see `LICENSE`. The repository's license covers this starter's original files, not third-party platform APIs, hosted website code, or brand assets.
