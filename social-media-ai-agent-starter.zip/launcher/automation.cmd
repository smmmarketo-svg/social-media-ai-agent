@echo off
setlocal
if /I "%~1"=="start" goto launch
if /I "%~1"=="help" goto help
if /I "%~1"=="--help" goto help
if /I "%~1"=="version" goto version
if /I "%~1"=="--version" goto version
if "%~1"=="" goto help
echo Unknown command: %~1
:help
echo Social Media AI Agent launcher 0.1.0
echo Usage: automation start ^| help ^| version
echo.
echo The start command opens the separately hosted PHP dashboard.
exit /b 0
:version
echo 0.1.0
exit /b 0
:launch
start "" "https://bajarmart.com/index.php"
if errorlevel 1 (
  echo Unable to open browser. Visit https://bajarmart.com/index.php manually.
  exit /b 1
)
echo Opened the dashboard in your default browser. Login may be required.
exit /b 0
