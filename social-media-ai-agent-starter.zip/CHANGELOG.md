# Changelog

## 0.1.0 — starter

- Six portable, instruction-only AI Agent Skills.
- Windows launcher and local installer.
- Architecture, security, and proposed integration API contract.
- No production API integration or publishing capability in this release.
